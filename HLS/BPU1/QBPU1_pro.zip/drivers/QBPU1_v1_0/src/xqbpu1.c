// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xqbpu1.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XQbpu1_CfgInitialize(XQbpu1 *InstancePtr, XQbpu1_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Config_BaseAddress = ConfigPtr->Config_BaseAddress;
    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XQbpu1_Start(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL) & 0x80;
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XQbpu1_IsDone(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XQbpu1_IsIdle(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XQbpu1_IsReady(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XQbpu1_EnableAutoRestart(XQbpu1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XQbpu1_DisableAutoRestart(XQbpu1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_AP_CTRL, 0);
}

void XQbpu1_Set_rescale1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_RESCALE1_DATA, Data);
}

u32 XQbpu1_Get_rescale1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_RESCALE1_DATA);
    return Data;
}

void XQbpu1_Set_rescale2(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_RESCALE2_DATA, Data);
}

u32 XQbpu1_Get_rescale2(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_RESCALE2_DATA);
    return Data;
}

void XQbpu1_Set_id_rescale(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_ID_RESCALE_DATA, Data);
}

u32 XQbpu1_Get_id_rescale(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_ID_RESCALE_DATA);
    return Data;
}

void XQbpu1_Set_R1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_R1_DATA, Data);
}

u32 XQbpu1_Get_R1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_R1_DATA);
    return Data;
}

void XQbpu1_Set_C1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_C1_DATA, Data);
}

u32 XQbpu1_Get_C1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_C1_DATA);
    return Data;
}

void XQbpu1_Set_M1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_M1_DATA, Data);
}

u32 XQbpu1_Get_M1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_M1_DATA);
    return Data;
}

void XQbpu1_Set_N1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_N1_DATA, Data);
}

u32 XQbpu1_Get_N1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_N1_DATA);
    return Data;
}

void XQbpu1_Set_K1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_K1_DATA, Data);
}

u32 XQbpu1_Get_K1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_K1_DATA);
    return Data;
}

void XQbpu1_Set_PadN1(XQbpu1 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_PADN1_DATA, Data);
}

u32 XQbpu1_Get_PadN1(XQbpu1 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Config_BaseAddress, XQBPU1_CONFIG_ADDR_PADN1_DATA);
    return Data;
}

void XQbpu1_Set_In_ddrsrc(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IN_DDRSRC_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IN_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_In_ddrsrc(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IN_DDRSRC_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IN_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Normq_ddrsrc(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_NORMQ_DDRSRC_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_NORMQ_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Normq_ddrsrc(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_NORMQ_DDRSRC_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_NORMQ_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Wt7x7_ddrsrc(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT7X7_DDRSRC_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT7X7_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Wt7x7_ddrsrc(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT7X7_DDRSRC_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT7X7_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Wt1_ddrsrc(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT1_DDRSRC_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT1_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Wt1_ddrsrc(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT1_DDRSRC_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT1_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Wt2_ddrsrc(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT2_DDRSRC_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT2_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Wt2_ddrsrc(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT2_DDRSRC_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_WT2_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Branch_ddr(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_BRANCH_DDR_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_BRANCH_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Branch_ddr(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_BRANCH_DDR_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_BRANCH_DDR_DATA + 4) << 32;
    return Data;
}

void XQbpu1_Set_Out_ddr(XQbpu1 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_OUT_DDR_DATA, (u32)(Data));
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_OUT_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu1_Get_Out_ddr(XQbpu1 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_OUT_DDR_DATA);
    Data += (u64)XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_OUT_DDR_DATA + 4) << 32;
    return Data;
}

void XQbpu1_InterruptGlobalEnable(XQbpu1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_GIE, 1);
}

void XQbpu1_InterruptGlobalDisable(XQbpu1 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_GIE, 0);
}

void XQbpu1_InterruptEnable(XQbpu1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IER);
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IER, Register | Mask);
}

void XQbpu1_InterruptDisable(XQbpu1 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IER);
    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IER, Register & (~Mask));
}

void XQbpu1_InterruptClear(XQbpu1 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu1_WriteReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_ISR, Mask);
}

u32 XQbpu1_InterruptGetEnabled(XQbpu1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_IER);
}

u32 XQbpu1_InterruptGetStatus(XQbpu1 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XQbpu1_ReadReg(InstancePtr->Control_BaseAddress, XQBPU1_CONTROL_ADDR_ISR);
}

