// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xqbpu1.h"

extern XQbpu1_Config XQbpu1_ConfigTable[];

XQbpu1_Config *XQbpu1_LookupConfig(u16 DeviceId) {
	XQbpu1_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XQBPU1_NUM_INSTANCES; Index++) {
		if (XQbpu1_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XQbpu1_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XQbpu1_Initialize(XQbpu1 *InstancePtr, u16 DeviceId) {
	XQbpu1_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XQbpu1_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XQbpu1_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

