// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// CONFIG
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of rescale1
//        bit 31~0 - rescale1[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of rescale2
//        bit 31~0 - rescale2[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of id_rescale
//        bit 31~0 - id_rescale[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of R1
//        bit 31~0 - R1[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of C1
//        bit 31~0 - C1[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of M1
//        bit 31~0 - M1[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of N1
//        bit 31~0 - N1[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of K1
//        bit 31~0 - K1[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of PadN1
//        bit 31~0 - PadN1[31:0] (Read/Write)
// 0x54 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XQBPU1_CONFIG_ADDR_RESCALE1_DATA   0x10
#define XQBPU1_CONFIG_BITS_RESCALE1_DATA   32
#define XQBPU1_CONFIG_ADDR_RESCALE2_DATA   0x18
#define XQBPU1_CONFIG_BITS_RESCALE2_DATA   32
#define XQBPU1_CONFIG_ADDR_ID_RESCALE_DATA 0x20
#define XQBPU1_CONFIG_BITS_ID_RESCALE_DATA 32
#define XQBPU1_CONFIG_ADDR_R1_DATA         0x28
#define XQBPU1_CONFIG_BITS_R1_DATA         32
#define XQBPU1_CONFIG_ADDR_C1_DATA         0x30
#define XQBPU1_CONFIG_BITS_C1_DATA         32
#define XQBPU1_CONFIG_ADDR_M1_DATA         0x38
#define XQBPU1_CONFIG_BITS_M1_DATA         32
#define XQBPU1_CONFIG_ADDR_N1_DATA         0x40
#define XQBPU1_CONFIG_BITS_N1_DATA         32
#define XQBPU1_CONFIG_ADDR_K1_DATA         0x48
#define XQBPU1_CONFIG_BITS_K1_DATA         32
#define XQBPU1_CONFIG_ADDR_PADN1_DATA      0x50
#define XQBPU1_CONFIG_BITS_PADN1_DATA      32

// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - enable ap_done interrupt (Read/Write)
//        bit 1  - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - ap_done (COR/TOW)
//        bit 1  - ap_ready (COR/TOW)
//        others - reserved
// 0x10 : Data signal of In_ddrsrc
//        bit 31~0 - In_ddrsrc[31:0] (Read/Write)
// 0x14 : Data signal of In_ddrsrc
//        bit 31~0 - In_ddrsrc[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of Normq_ddrsrc
//        bit 31~0 - Normq_ddrsrc[31:0] (Read/Write)
// 0x20 : Data signal of Normq_ddrsrc
//        bit 31~0 - Normq_ddrsrc[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of Wt7x7_ddrsrc
//        bit 31~0 - Wt7x7_ddrsrc[31:0] (Read/Write)
// 0x2c : Data signal of Wt7x7_ddrsrc
//        bit 31~0 - Wt7x7_ddrsrc[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of Wt1_ddrsrc
//        bit 31~0 - Wt1_ddrsrc[31:0] (Read/Write)
// 0x38 : Data signal of Wt1_ddrsrc
//        bit 31~0 - Wt1_ddrsrc[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of Wt2_ddrsrc
//        bit 31~0 - Wt2_ddrsrc[31:0] (Read/Write)
// 0x44 : Data signal of Wt2_ddrsrc
//        bit 31~0 - Wt2_ddrsrc[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of Branch_ddr
//        bit 31~0 - Branch_ddr[31:0] (Read/Write)
// 0x50 : Data signal of Branch_ddr
//        bit 31~0 - Branch_ddr[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of Out_ddr
//        bit 31~0 - Out_ddr[31:0] (Read/Write)
// 0x5c : Data signal of Out_ddr
//        bit 31~0 - Out_ddr[63:32] (Read/Write)
// 0x60 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XQBPU1_CONTROL_ADDR_AP_CTRL           0x00
#define XQBPU1_CONTROL_ADDR_GIE               0x04
#define XQBPU1_CONTROL_ADDR_IER               0x08
#define XQBPU1_CONTROL_ADDR_ISR               0x0c
#define XQBPU1_CONTROL_ADDR_IN_DDRSRC_DATA    0x10
#define XQBPU1_CONTROL_BITS_IN_DDRSRC_DATA    64
#define XQBPU1_CONTROL_ADDR_NORMQ_DDRSRC_DATA 0x1c
#define XQBPU1_CONTROL_BITS_NORMQ_DDRSRC_DATA 64
#define XQBPU1_CONTROL_ADDR_WT7X7_DDRSRC_DATA 0x28
#define XQBPU1_CONTROL_BITS_WT7X7_DDRSRC_DATA 64
#define XQBPU1_CONTROL_ADDR_WT1_DDRSRC_DATA   0x34
#define XQBPU1_CONTROL_BITS_WT1_DDRSRC_DATA   64
#define XQBPU1_CONTROL_ADDR_WT2_DDRSRC_DATA   0x40
#define XQBPU1_CONTROL_BITS_WT2_DDRSRC_DATA   64
#define XQBPU1_CONTROL_ADDR_BRANCH_DDR_DATA   0x4c
#define XQBPU1_CONTROL_BITS_BRANCH_DDR_DATA   64
#define XQBPU1_CONTROL_ADDR_OUT_DDR_DATA      0x58
#define XQBPU1_CONTROL_BITS_OUT_DDR_DATA      64

