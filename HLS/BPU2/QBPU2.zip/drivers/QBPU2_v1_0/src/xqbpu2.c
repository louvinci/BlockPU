// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xqbpu2.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XQbpu2_CfgInitialize(XQbpu2 *InstancePtr, XQbpu2_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Config_BaseAddress = ConfigPtr->Config_BaseAddress;
    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XQbpu2_Start(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL) & 0x80;
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XQbpu2_IsDone(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XQbpu2_IsIdle(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XQbpu2_IsReady(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XQbpu2_EnableAutoRestart(XQbpu2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XQbpu2_DisableAutoRestart(XQbpu2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_AP_CTRL, 0);
}

void XQbpu2_Set_rescale1(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_RESCALE1_DATA, Data);
}

u32 XQbpu2_Get_rescale1(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_RESCALE1_DATA);
    return Data;
}

void XQbpu2_Set_rescale2(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_RESCALE2_DATA, Data);
}

u32 XQbpu2_Get_rescale2(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_RESCALE2_DATA);
    return Data;
}

void XQbpu2_Set_id_rescale(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_ID_RESCALE_DATA, Data);
}

u32 XQbpu2_Get_id_rescale(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_ID_RESCALE_DATA);
    return Data;
}

void XQbpu2_Set_R1(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_R1_DATA, Data);
}

u32 XQbpu2_Get_R1(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_R1_DATA);
    return Data;
}

void XQbpu2_Set_C1(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_C1_DATA, Data);
}

u32 XQbpu2_Get_C1(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_C1_DATA);
    return Data;
}

void XQbpu2_Set_M1(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_M1_DATA, Data);
}

u32 XQbpu2_Get_M1(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_M1_DATA);
    return Data;
}

void XQbpu2_Set_N1(XQbpu2 *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_N1_DATA, Data);
}

u32 XQbpu2_Get_N1(XQbpu2 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Config_BaseAddress, XQBPU2_CONFIG_ADDR_N1_DATA);
    return Data;
}

void XQbpu2_Set_In_ddrsrc(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IN_DDRSRC_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IN_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_In_ddrsrc(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IN_DDRSRC_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IN_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Normq_ddrsrc(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_NORMQ_DDRSRC_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_NORMQ_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Normq_ddrsrc(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_NORMQ_DDRSRC_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_NORMQ_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Wt7x7_ddrsrc(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT7X7_DDRSRC_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT7X7_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Wt7x7_ddrsrc(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT7X7_DDRSRC_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT7X7_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Wt1_ddrsrc(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT1_DDRSRC_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT1_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Wt1_ddrsrc(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT1_DDRSRC_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT1_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Wt2_ddrsrc(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT2_DDRSRC_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT2_DDRSRC_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Wt2_ddrsrc(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT2_DDRSRC_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_WT2_DDRSRC_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Branch_ddr(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_BRANCH_DDR_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_BRANCH_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Branch_ddr(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_BRANCH_DDR_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_BRANCH_DDR_DATA + 4) << 32;
    return Data;
}

void XQbpu2_Set_Out_ddr(XQbpu2 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_OUT_DDR_DATA, (u32)(Data));
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_OUT_DDR_DATA + 4, (u32)(Data >> 32));
}

u64 XQbpu2_Get_Out_ddr(XQbpu2 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_OUT_DDR_DATA);
    Data += (u64)XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_OUT_DDR_DATA + 4) << 32;
    return Data;
}

void XQbpu2_InterruptGlobalEnable(XQbpu2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_GIE, 1);
}

void XQbpu2_InterruptGlobalDisable(XQbpu2 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_GIE, 0);
}

void XQbpu2_InterruptEnable(XQbpu2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IER);
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IER, Register | Mask);
}

void XQbpu2_InterruptDisable(XQbpu2 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IER);
    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IER, Register & (~Mask));
}

void XQbpu2_InterruptClear(XQbpu2 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XQbpu2_WriteReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_ISR, Mask);
}

u32 XQbpu2_InterruptGetEnabled(XQbpu2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_IER);
}

u32 XQbpu2_InterruptGetStatus(XQbpu2 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XQbpu2_ReadReg(InstancePtr->Control_BaseAddress, XQBPU2_CONTROL_ADDR_ISR);
}

