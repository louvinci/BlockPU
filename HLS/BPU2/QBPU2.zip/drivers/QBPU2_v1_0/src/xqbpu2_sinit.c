// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xqbpu2.h"

extern XQbpu2_Config XQbpu2_ConfigTable[];

XQbpu2_Config *XQbpu2_LookupConfig(u16 DeviceId) {
	XQbpu2_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XQBPU2_NUM_INSTANCES; Index++) {
		if (XQbpu2_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XQbpu2_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XQbpu2_Initialize(XQbpu2 *InstancePtr, u16 DeviceId) {
	XQbpu2_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XQbpu2_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XQbpu2_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

