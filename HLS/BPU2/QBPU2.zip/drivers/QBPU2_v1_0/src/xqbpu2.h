// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XQBPU2_H
#define XQBPU2_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xqbpu2_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Config_BaseAddress;
    u32 Control_BaseAddress;
} XQbpu2_Config;
#endif

typedef struct {
    u64 Config_BaseAddress;
    u64 Control_BaseAddress;
    u32 IsReady;
} XQbpu2;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XQbpu2_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XQbpu2_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XQbpu2_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XQbpu2_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XQbpu2_Initialize(XQbpu2 *InstancePtr, u16 DeviceId);
XQbpu2_Config* XQbpu2_LookupConfig(u16 DeviceId);
int XQbpu2_CfgInitialize(XQbpu2 *InstancePtr, XQbpu2_Config *ConfigPtr);
#else
int XQbpu2_Initialize(XQbpu2 *InstancePtr, const char* InstanceName);
int XQbpu2_Release(XQbpu2 *InstancePtr);
#endif

void XQbpu2_Start(XQbpu2 *InstancePtr);
u32 XQbpu2_IsDone(XQbpu2 *InstancePtr);
u32 XQbpu2_IsIdle(XQbpu2 *InstancePtr);
u32 XQbpu2_IsReady(XQbpu2 *InstancePtr);
void XQbpu2_EnableAutoRestart(XQbpu2 *InstancePtr);
void XQbpu2_DisableAutoRestart(XQbpu2 *InstancePtr);

void XQbpu2_Set_rescale1(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_rescale1(XQbpu2 *InstancePtr);
void XQbpu2_Set_rescale2(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_rescale2(XQbpu2 *InstancePtr);
void XQbpu2_Set_id_rescale(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_id_rescale(XQbpu2 *InstancePtr);
void XQbpu2_Set_R1(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_R1(XQbpu2 *InstancePtr);
void XQbpu2_Set_C1(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_C1(XQbpu2 *InstancePtr);
void XQbpu2_Set_M1(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_M1(XQbpu2 *InstancePtr);
void XQbpu2_Set_N1(XQbpu2 *InstancePtr, u32 Data);
u32 XQbpu2_Get_N1(XQbpu2 *InstancePtr);
void XQbpu2_Set_In_ddrsrc(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_In_ddrsrc(XQbpu2 *InstancePtr);
void XQbpu2_Set_Normq_ddrsrc(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Normq_ddrsrc(XQbpu2 *InstancePtr);
void XQbpu2_Set_Wt7x7_ddrsrc(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Wt7x7_ddrsrc(XQbpu2 *InstancePtr);
void XQbpu2_Set_Wt1_ddrsrc(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Wt1_ddrsrc(XQbpu2 *InstancePtr);
void XQbpu2_Set_Wt2_ddrsrc(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Wt2_ddrsrc(XQbpu2 *InstancePtr);
void XQbpu2_Set_Branch_ddr(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Branch_ddr(XQbpu2 *InstancePtr);
void XQbpu2_Set_Out_ddr(XQbpu2 *InstancePtr, u64 Data);
u64 XQbpu2_Get_Out_ddr(XQbpu2 *InstancePtr);

void XQbpu2_InterruptGlobalEnable(XQbpu2 *InstancePtr);
void XQbpu2_InterruptGlobalDisable(XQbpu2 *InstancePtr);
void XQbpu2_InterruptEnable(XQbpu2 *InstancePtr, u32 Mask);
void XQbpu2_InterruptDisable(XQbpu2 *InstancePtr, u32 Mask);
void XQbpu2_InterruptClear(XQbpu2 *InstancePtr, u32 Mask);
u32 XQbpu2_InterruptGetEnabled(XQbpu2 *InstancePtr);
u32 XQbpu2_InterruptGetStatus(XQbpu2 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
