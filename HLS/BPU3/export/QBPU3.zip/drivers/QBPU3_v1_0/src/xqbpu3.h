// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XQBPU3_H
#define XQBPU3_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xqbpu3_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Config_BaseAddress;
    u32 Control_BaseAddress;
} XQbpu3_Config;
#endif

typedef struct {
    u64 Config_BaseAddress;
    u64 Control_BaseAddress;
    u32 IsReady;
} XQbpu3;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XQbpu3_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XQbpu3_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XQbpu3_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XQbpu3_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XQbpu3_Initialize(XQbpu3 *InstancePtr, u16 DeviceId);
XQbpu3_Config* XQbpu3_LookupConfig(u16 DeviceId);
int XQbpu3_CfgInitialize(XQbpu3 *InstancePtr, XQbpu3_Config *ConfigPtr);
#else
int XQbpu3_Initialize(XQbpu3 *InstancePtr, const char* InstanceName);
int XQbpu3_Release(XQbpu3 *InstancePtr);
#endif

void XQbpu3_Start(XQbpu3 *InstancePtr);
u32 XQbpu3_IsDone(XQbpu3 *InstancePtr);
u32 XQbpu3_IsIdle(XQbpu3 *InstancePtr);
u32 XQbpu3_IsReady(XQbpu3 *InstancePtr);
void XQbpu3_EnableAutoRestart(XQbpu3 *InstancePtr);
void XQbpu3_DisableAutoRestart(XQbpu3 *InstancePtr);

void XQbpu3_Set_rescale1(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_rescale1(XQbpu3 *InstancePtr);
void XQbpu3_Set_rescale2(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_rescale2(XQbpu3 *InstancePtr);
void XQbpu3_Set_id_rescale(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_id_rescale(XQbpu3 *InstancePtr);
void XQbpu3_Set_R1(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_R1(XQbpu3 *InstancePtr);
void XQbpu3_Set_C1(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_C1(XQbpu3 *InstancePtr);
void XQbpu3_Set_M1(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_M1(XQbpu3 *InstancePtr);
void XQbpu3_Set_N1(XQbpu3 *InstancePtr, u32 Data);
u32 XQbpu3_Get_N1(XQbpu3 *InstancePtr);
void XQbpu3_Set_In_ddrsrc(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_In_ddrsrc(XQbpu3 *InstancePtr);
void XQbpu3_Set_Normq_ddrsrc(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Normq_ddrsrc(XQbpu3 *InstancePtr);
void XQbpu3_Set_Wt7x7_ddrsrc(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Wt7x7_ddrsrc(XQbpu3 *InstancePtr);
void XQbpu3_Set_Wt1_ddrsrc(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Wt1_ddrsrc(XQbpu3 *InstancePtr);
void XQbpu3_Set_Wt2_ddrsrc(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Wt2_ddrsrc(XQbpu3 *InstancePtr);
void XQbpu3_Set_Branch_ddr(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Branch_ddr(XQbpu3 *InstancePtr);
void XQbpu3_Set_Out_ddr(XQbpu3 *InstancePtr, u64 Data);
u64 XQbpu3_Get_Out_ddr(XQbpu3 *InstancePtr);

void XQbpu3_InterruptGlobalEnable(XQbpu3 *InstancePtr);
void XQbpu3_InterruptGlobalDisable(XQbpu3 *InstancePtr);
void XQbpu3_InterruptEnable(XQbpu3 *InstancePtr, u32 Mask);
void XQbpu3_InterruptDisable(XQbpu3 *InstancePtr, u32 Mask);
void XQbpu3_InterruptClear(XQbpu3 *InstancePtr, u32 Mask);
u32 XQbpu3_InterruptGetEnabled(XQbpu3 *InstancePtr);
u32 XQbpu3_InterruptGetStatus(XQbpu3 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
